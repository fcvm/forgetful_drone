If you are using Windows, you should install the following tools:

1. Miktex (newest and full version in order to avoid problems) miktex.org/
2. texniccenter www.texniccenter.org/

For Linux following tools are interesting:

-gedit
-vi
-rubber
-...